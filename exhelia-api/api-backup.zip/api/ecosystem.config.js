module.exports = {
  apps: [{
    name: 'exhelia-api',
    script: './src/index.js',
    cwd: '/home/exhelia/api',
    env: {
      NODE_ENV: 'production',
      PORT: '3000',
      DB_HOST: 'localhost',
      DB_PORT: '5432',
      DB_NAME: 'exhelia',
      DB_USER: 'exhelia',
      DB_PASSWORD: 'Exhelia67@**-Itikotiko-Vakacegu-katakata',
      JWT_SECRET: 'hhXqdmJgVsyLrkEvWybxfrtScnRSbv8egGvczHqunyRbmTaAkfbFqPWdTu7TtG9s',
      ALLOWED_ORIGINS: '*',
      SENSOR_API_KEY: 'q7ibA9f3Gd6K6ALYvZ3Uq87F8Yc4fhRDF9xFodQFsGqkgBoeGV9EA2rmD7jRR3Qn'
    }
  }]
}
