# 🚀 Guide d'installation — Exhelia API sur VPS Ubuntu 24.04

## 1. Configurer PostgreSQL

```bash
# Connexion à postgres
sudo -u postgres psql

# Créer la base et l'utilisateur
CREATE DATABASE exhelia;
CREATE USER exhelia WITH PASSWORD 'MON_MOT_DE_PASSE_FORT';
GRANT ALL PRIVILEGES ON DATABASE exhelia TO exhelia;
\c exhelia
GRANT ALL ON SCHEMA public TO exhelia;
\q

# Importer le schéma
sudo -u postgres psql -d exhelia -f /home/exhelia/api/schema.sql
```

## 2. Installer et démarrer l'API

```bash
# Cloner / uploader le projet dans /home/exhelia/api
cd /home/exhelia/api

# Installer les dépendances
npm install

# Copier et configurer les variables d'environnement
cp .env.example .env
nano .env   # ← Remplir les valeurs réelles

# Démarrer avec PM2 (reste actif après reboot)
pm2 start src/index.js --name exhelia-api
pm2 save
pm2 startup   # ← Copier-coller la commande affichée
```

## 3. Configurer Nginx (reverse proxy)

```bash
sudo nano /etc/nginx/sites-available/exhelia-api
```

```nginx
server {
    listen 80;
    server_name api.exhelia.fr;

    # Upload photos (max 20MB)
    client_max_body_size 20M;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';   # WebSocket
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }

    # Fichiers statiques (photos uploadées)
    location /uploads/ {
        alias /home/exhelia/api/uploads/;
        expires 30d;
        add_header Cache-Control "public, immutable";
    }
}
```

```bash
# Activer le site
sudo ln -s /etc/nginx/sites-available/exhelia-api /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# HTTPS avec Certbot
sudo certbot --nginx -d api.exhelia.fr
```

## 4. Vérifier que tout fonctionne

```bash
# Health check
curl https://api.exhelia.fr/health

# Voir les logs en temps réel
pm2 logs exhelia-api
```

## 5. Structure des dossiers sur le VPS

```
/home/exhelia/
└── api/
    ├── src/
    ├── uploads/
    │   ├── photos/       ← Photos interventions (WebP compressé)
    │   └── signatures/   ← Signatures clients (PNG)
    ├── .env
    └── package.json
```

## 6. Endpoints API — Résumé

| Méthode | Endpoint | Rôles | Description |
|---------|----------|-------|-------------|
| POST | /api/auth/login | tous | Connexion |
| POST | /api/auth/refresh | tous | Renouveler token |
| GET | /api/interventions | bureau/technicien | Liste interventions |
| POST | /api/interventions | bureau/admin | Créer intervention |
| PATCH | /api/interventions/:id | bureau/admin | Modifier intervention |
| GET | /api/rapports/:intervention_id | bureau/technicien | Voir rapport |
| POST | /api/rapports | technicien | Soumettre rapport |
| POST | /api/rapports/:id/photos | technicien | Upload photos |
| POST | /api/rapports/:id/signature | technicien | Enregistrer signature |
| PATCH | /api/rapports/:id | bureau/admin | Modifier rapport |
| GET | /api/recherche?q=... | bureau/admin | Recherche globale |
| GET | /api/export/interventions | bureau/admin | Export CSV |
| GET | /api/capteurs/:id/mesures | tous | Données capteur |
| POST | /api/capteurs/:id/mesures | IoT (API key) | Ingest mesure |

## WebSocket

Connexion : `wss://api.exhelia.fr/ws?token=ACCESS_TOKEN`

Événements reçus :
- `intervention:created` — Nouvelle intervention créée
- `intervention:updated` — Intervention modifiée
- `intervention:cancelled` — Intervention annulée
- `rapport:updated` — Rapport en cours de remplissage
- `rapport:validated` — Rapport validé par technicien
