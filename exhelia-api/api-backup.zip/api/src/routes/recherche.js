const router = require('express').Router();
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// GET /api/recherche?q= — groupé par client
router.get('/', auth, roles('admin', 'bureau'), async (req, res) => {
    const { q, page = 1, limit = 20 } = req.query;
    if (!q || q.length < 2)
        return res.status(400).json({ error: 'Requete trop courte (min 2 caracteres)' });
    const offset = (page - 1) * limit;
    try {
        const { rows: clients } = await db.query(`
            SELECT DISTINCT c.id, c.nom, c.prenom, c.type, c.telephone, u.email,
                (SELECT COUNT(*) FROM logements l2 WHERE l2.client_id = c.id) AS nb_logements,
                (SELECT l3.id FROM logements l3
                 WHERE l3.client_id = c.id
                 AND (
                   unaccent(l3.nom_locataire) ILIKE '%' || unaccent($1) || '%'
                   OR unaccent(l3.adresse) ILIKE '%' || unaccent($1) || '%'
                   OR unaccent(l3.ville) ILIKE '%' || unaccent($1) || '%'
                 )
                 ORDER BY l3.id LIMIT 1
                ) AS matched_logement_id
            FROM clients c
            JOIN users u ON u.id = c.user_id
            LEFT JOIN logements l ON l.client_id = c.id
            WHERE
                unaccent(c.nom) ILIKE '%' || unaccent($1) || '%'
                OR unaccent(c.prenom) ILIKE '%' || unaccent($1) || '%'
                OR unaccent(l.adresse) ILIKE '%' || unaccent($1) || '%'
                OR unaccent(l.nom_locataire) ILIKE '%' || unaccent($1) || '%'
                OR unaccent(l.ville) ILIKE '%' || unaccent($1) || '%'
            ORDER BY c.nom ASC
            LIMIT $2 OFFSET $3
        `, [q, limit, offset]);

        const enriched = await Promise.all(clients.map(async (c) => {
            const { rows: stats } = await db.query(`
                SELECT COUNT(i.id) AS total_interventions,
                    SUM(CASE WHEN i.statut = 'terminee' THEN 1 ELSE 0 END) AS terminees,
                    MAX(i.date_prevue) AS derniere_intervention
                FROM interventions i
                JOIN logements l ON l.id = i.logement_id
                WHERE l.client_id = $1
            `, [c.id]);
            return { ...c, stats: stats[0] };
        }));

        res.json({ data: enriched, total: enriched.length, query: q });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

// GET /api/recherche/client/:id — logements du client
router.get('/client/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        const { rows: cr } = await db.query(
            'SELECT c.*, u.email FROM clients c JOIN users u ON u.id = c.user_id WHERE c.id = $1',
            [req.params.id]
        );
        if (!cr[0]) return res.status(404).json({ error: 'Client introuvable' });

        const { rows: logements } = await db.query(`
            SELECT l.*,
                (SELECT COUNT(*) FROM interventions WHERE logement_id = l.id) AS nb_interventions,
                (SELECT COUNT(*) FROM interventions WHERE logement_id = l.id AND statut = 'terminee') AS nb_terminees,
                (SELECT MAX(date_prevue) FROM interventions WHERE logement_id = l.id) AS derniere_intervention
            FROM logements l
            WHERE l.client_id = $1
            ORDER BY l.adresse ASC, l.etage ASC
        `, [req.params.id]);

        res.json({ client: cr[0], logements });
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// PATCH /api/recherche/client/:id — modifier infos client
router.patch('/client/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    const allowed = ['nom','prenom','telephone','raison_sociale','siret'];
    const updates = []; const params = [];
    Object.entries(req.body).forEach(([k,v]) => {
        if (allowed.includes(k)) { params.push(v); updates.push(`${k}=$${params.length}`); }
    });
    if (!updates.length) return res.status(400).json({ error: 'Aucun champ valide' });
    params.push(req.params.id);
    try {
        const { rows } = await db.query(
            `UPDATE clients SET ${updates.join(',')} WHERE id=$${params.length} RETURNING *`, params
        );
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// GET /api/recherche/logement/:id — detail logement + interventions
router.get('/logement/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        const { rows: lr } = await db.query(`
            SELECT l.*, c.id AS client_id, c.nom AS client_nom, c.prenom AS client_prenom,
                c.type AS client_type, c.telephone AS client_tel, u.email AS client_email
            FROM logements l
            JOIN clients c ON c.id = l.client_id
            JOIN users u ON u.id = c.user_id
            WHERE l.id = $1
        `, [req.params.id]);
        if (!lr[0]) return res.status(404).json({ error: 'Logement introuvable' });

        const { rows: interventions } = await db.query(`
            SELECT i.*, t.nom AS tech_nom, t.prenom AS tech_prenom,
                r.id AS rapport_id, r.valide AS rapport_valide
            FROM interventions i
            LEFT JOIN techniciens t ON t.id = i.technicien_id
            LEFT JOIN rapports r ON r.intervention_id = i.id
            WHERE i.logement_id = $1
            ORDER BY i.date_prevue DESC
        `, [req.params.id]);

        res.json({ logement: lr[0], interventions });
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// PATCH /api/recherche/logement/:id — modifier logement
router.patch('/logement/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    const allowed = ['adresse','complement','ville','code_postal','etage','numero_porte','digicode','telephone_loc','nom_locataire'];
    const updates = []; const params = [];
    Object.entries(req.body).forEach(([k,v]) => {
        if (allowed.includes(k)) { params.push(v); updates.push(`${k}=$${params.length}`); }
    });
    if (!updates.length) return res.status(400).json({ error: 'Aucun champ valide' });
    params.push(req.params.id);
    try {
        const { rows } = await db.query(
            `UPDATE logements SET ${updates.join(',')} WHERE id=$${params.length} RETURNING *`, params
        );
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// POST /api/recherche/logement — ajouter logement a un client
router.post('/logement', auth, roles('admin', 'bureau'), async (req, res) => {
    const { client_id, adresse, ville, code_postal, etage, numero_porte, digicode, telephone_loc, nom_locataire } = req.body;
    if (!client_id || !adresse || !ville || !code_postal)
        return res.status(400).json({ error: 'Champs obligatoires manquants' });
    try {
        const { rows } = await db.query(`
            INSERT INTO logements (client_id, adresse, ville, code_postal, etage, numero_porte, digicode, telephone_loc, nom_locataire)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *
        `, [client_id, adresse, ville, code_postal, etage||null, numero_porte||null, digicode||null, telephone_loc||null, nom_locataire||null]);
        res.status(201).json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// GET /api/recherche/interventions?q=...
router.get('/interventions', auth, roles('admin', 'bureau'), async (req, res) => {
    const { q, date_debut, date_fin, technicien_id, statut, type } = req.query;
    const params = [];
    const conditions = ['1=1'];
    if (q) {
        params.push(q);
        conditions.push(`(
            unaccent(l.adresse) ILIKE '%' || unaccent($${params.length}) || '%'
            OR unaccent(c.nom) ILIKE '%' || unaccent($${params.length}) || '%'
            OR unaccent(l.nom_locataire) ILIKE '%' || unaccent($${params.length}) || '%'
        )`);
    }
    if (date_debut) { params.push(date_debut); conditions.push(`i.date_prevue >= $${params.length}`); }
    if (date_fin)   { params.push(date_fin);   conditions.push(`i.date_prevue <= $${params.length}`); }
    if (technicien_id) { params.push(technicien_id); conditions.push(`i.technicien_id = $${params.length}`); }
    if (statut)     { params.push(statut); conditions.push(`i.statut = $${params.length}`); }
    if (type)       { params.push(type);   conditions.push(`i.type = $${params.length}`); }

    try {
        const { rows } = await db.query(`
            SELECT i.*, l.adresse, l.ville, l.nom_locataire, c.nom AS client_nom,
                t.nom AS tech_nom, t.prenom AS tech_prenom,
                r.id AS rapport_id, r.valide AS rapport_valide
            FROM interventions i
            JOIN logements l ON l.id = i.logement_id
            JOIN clients c ON c.id = l.client_id
            LEFT JOIN techniciens t ON t.id = i.technicien_id
            LEFT JOIN rapports r ON r.intervention_id = i.id
            WHERE ${conditions.join(' AND ')}
            ORDER BY i.date_prevue DESC, i.heure_prevue ASC
            LIMIT 100
        `, params);
        res.json({ data: rows, total: rows.length });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
