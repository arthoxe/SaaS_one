const router = require('express').Router();
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');
const { broadcast } = require('../utils/websocket');

// ── GET /api/interventions ──
router.get('/', auth, async (req, res) => {
    try {
        const { date, date_debut, date_fin, statut, technicien_id, type, logement_id, page = 1, limit = 200 } = req.query;
        const offset = (page - 1) * limit;
        const params = [];
        const conditions = [];

        if (req.user.role === 'technicien') {
            params.push(req.user.profil_id);
            conditions.push(`i.technicien_id = $${params.length}`);
        } else if (req.user.role === 'bureau') {
            params.push(req.user.profil_id);
            conditions.push(`i.created_by = $${params.length}`);
        }

        if (technicien_id) { params.push(technicien_id); conditions.push(`i.technicien_id = $${params.length}`); }
        if (date)          { params.push(date); conditions.push(`i.date_prevue = $${params.length}`); }
        if (date_debut)    { params.push(date_debut); conditions.push(`i.date_prevue >= $${params.length}`); }
        if (date_fin)      { params.push(date_fin); conditions.push(`i.date_prevue <= $${params.length}`); }
        if (statut)        { params.push(statut); conditions.push(`i.statut = $${params.length}`); }
        if (type)          { params.push(type); conditions.push(`i.type = $${params.length}`); }
        if (logement_id)   { params.push(logement_id); conditions.push(`i.logement_id = $${params.length}`); }

        const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

        const query = `
            SELECT i.*,
                l.adresse, l.ville, l.code_postal, l.etage, l.numero_porte, l.digicode,
                l.telephone_loc, l.nom_locataire,
                c.nom AS client_nom, c.prenom AS client_prenom, c.type AS client_type,
                t.nom AS tech_nom, t.prenom AS tech_prenom, t.telephone AS tech_tel,
                r.id AS rapport_id, r.valide AS rapport_valide
            FROM interventions i
            JOIN logements l ON l.id = i.logement_id
            JOIN clients c ON c.id = l.client_id
            LEFT JOIN techniciens t ON t.id = i.technicien_id
            LEFT JOIN rapports r ON r.intervention_id = i.id
            ${where}
            ORDER BY i.date_prevue ASC, i.heure_prevue ASC
            LIMIT $${params.length + 1} OFFSET $${params.length + 2}
        `;
        params.push(limit, offset);
        const { rows } = await db.query(query, params);
        const countQuery = `SELECT COUNT(*) FROM interventions i ${where}`;
        const { rows: countRows } = await db.query(countQuery, params.slice(0, -2));

        res.json({ data: rows, total: parseInt(countRows[0].count), page: parseInt(page), limit: parseInt(limit) });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }); }
});

// ── GET /api/interventions/:id ──
router.get('/:id', auth, async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT i.*, l.adresse, l.ville, l.code_postal, l.etage, l.numero_porte,
                l.digicode, l.telephone_loc, l.nom_locataire,
                c.nom AS client_nom, c.prenom AS client_prenom,
                t.nom AS tech_nom, t.prenom AS tech_prenom
            FROM interventions i
            JOIN logements l ON l.id = i.logement_id
            JOIN clients c ON c.id = l.client_id
            LEFT JOIN techniciens t ON t.id = i.technicien_id
            WHERE i.id = $1
        `, [req.params.id]);
        if (!rows[0]) return res.status(404).json({ error: 'Intervention introuvable' });
        if (req.user.role === 'technicien' && rows[0].technicien_id !== req.user.profil_id)
            return res.status(403).json({ error: 'Accès refusé' });
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// ── POST /api/interventions ──
router.post('/', auth, roles('admin', 'bureau'), async (req, res) => {
    const { logement_id, equipement_id, technicien_id, type, date_prevue, date_fin,
            heure_prevue, heure_fin, duree_prevue, notes_bureau } = req.body;
    if (!logement_id || !type || !date_prevue)
        return res.status(400).json({ error: 'logement_id, type et date_prevue requis' });
    try {
        let chef_id = null;
        if (req.user.role === 'bureau') {
            const { rows } = await db.query('SELECT id FROM chefs_equipe WHERE user_id = $1', [req.user.id]);
            chef_id = rows[0]?.id;
        }
        const { rows } = await db.query(`
            INSERT INTO interventions
                (logement_id, equipement_id, technicien_id, chef_id, created_by, type,
                 date_prevue, date_fin, heure_prevue, heure_fin, duree_prevue, notes_bureau)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *
        `, [logement_id, equipement_id||null, technicien_id||null, chef_id, chef_id,
            type, date_prevue, date_fin||null, heure_prevue||null, heure_fin||null,
            duree_prevue||null, notes_bureau||null]);
        broadcast('intervention:created', rows[0]);
        res.status(201).json(rows[0]);
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }); }
});

// ── PATCH /api/interventions/:id ──
router.patch('/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    const allowed = ['technicien_id','date_prevue','date_fin','heure_prevue','heure_fin',
                     'duree_prevue','notes_bureau','statut','type'];
    const updates = []; const params = [];
    Object.entries(req.body).forEach(([key, val]) => {
        if (allowed.includes(key)) { params.push(val); updates.push(`${key} = $${params.length}`); }
    });
    if (!updates.length) return res.status(400).json({ error: 'Aucun champ valide' });
    params.push(req.params.id);
    try {
        const { rows } = await db.query(
            `UPDATE interventions SET ${updates.join(', ')}, updated_at = NOW() WHERE id = $${params.length} RETURNING *`,
            params
        );
        if (!rows[0]) return res.status(404).json({ error: 'Introuvable' });
        broadcast('intervention:updated', rows[0]);
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// ── DELETE /api/interventions/:id — SUPPRESSION DEFINITIVE ──
router.delete('/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        const result = await db.query('DELETE FROM interventions WHERE id = $1', [req.params.id]);
        if (result.rowCount === 0) return res.status(404).json({ error: 'Introuvable' });
        broadcast('intervention:deleted', { id: req.params.id });
        res.json({ message: 'Intervention supprimée' });
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
