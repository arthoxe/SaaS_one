const router = require('express').Router();
const multer = require('multer');
const sharp  = require('sharp');
const path   = require('path');
const fs     = require('fs');
const { v4: uuidv4 } = require('uuid');
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');
const { broadcast } = require('../utils/websocket');

// ── Config upload photos ──
const storage = multer.memoryStorage(); // stockage en mémoire pour compression avec sharp
const upload  = multer({
    storage,
    limits: { fileSize: 15 * 1024 * 1024 }, // 15MB max par photo
    fileFilter: (req, file, cb) => {
        if (file.mimetype.startsWith('image/')) cb(null, true);
        else cb(new Error('Seules les images sont acceptées'));
    }
});

// ── GET /api/rapports/:intervention_id ──
router.get('/:intervention_id', auth, async (req, res) => {
    try {
        const { rows } = await db.query(
            'SELECT * FROM rapports WHERE intervention_id = $1',
            [req.params.intervention_id]
        );
        if (!rows[0]) return res.status(404).json({ error: 'Rapport introuvable' });

        const rapport = rows[0];

        // Champs dynamiques
        const { rows: champs } = await db.query(
            'SELECT cle, valeur FROM rapport_champs WHERE rapport_id = $1',
            [rapport.id]
        );

        // Photos
        const { rows: photos } = await db.query(
            'SELECT id, chemin, legende, created_at FROM rapport_photos WHERE rapport_id = $1',
            [rapport.id]
        );

        // Signature
        const { rows: sigs } = await db.query(
            'SELECT signataire_nom, signed_at FROM rapport_signatures WHERE rapport_id = $1',
            [rapport.id]
        );

        res.json({
            ...rapport,
            champs: Object.fromEntries(champs.map(c => [c.cle, c.valeur])),
            photos,
            signature: sigs[0] || null
        });
    } catch (err) {
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

// ── POST /api/rapports ── Créer ou mettre à jour un rapport
router.post('/', auth, async (req, res) => {
    const {
        intervention_id, heure_debut, heure_fin,
        statut_equipement, travaux_effectues, fournitures,
        remarques, champs_specifiques, valider
    } = req.body;

    if (!intervention_id)
        return res.status(400).json({ error: 'intervention_id requis' });

    try {
        // Vérifier que l'intervention existe et appartient au technicien
        const { rows: inter } = await db.query(
            'SELECT * FROM interventions WHERE id = $1', [intervention_id]
        );
        if (!inter[0]) return res.status(404).json({ error: 'Intervention introuvable' });

        if (req.user.role === 'technicien' && inter[0].technicien_id !== req.user.profil_id)
            return res.status(403).json({ error: 'Accès refusé' });

        // Vérifier si rapport déjà validé (technicien ne peut plus modifier)
        const { rows: existing } = await db.query(
            'SELECT * FROM rapports WHERE intervention_id = $1', [intervention_id]
        );

        if (existing[0]?.valide && req.user.role === 'technicien')
            return res.status(403).json({ error: 'Rapport déjà validé, non modifiable' });

        let rapport;
        if (existing[0]) {
            // Mise à jour
            const { rows } = await db.query(`
                UPDATE rapports SET
                    heure_debut = $1, heure_fin = $2, statut_equipement = $3,
                    travaux_effectues = $4, fournitures = $5, remarques = $6,
                    valide = $7, updated_at = NOW()
                WHERE intervention_id = $8 RETURNING *
            `, [heure_debut, heure_fin, statut_equipement,
                travaux_effectues, fournitures, remarques,
                valider || false, intervention_id]);
            rapport = rows[0];
        } else {
            // Création
            const { rows } = await db.query(`
                INSERT INTO rapports
                    (intervention_id, technicien_id, heure_debut, heure_fin,
                     statut_equipement, travaux_effectues, fournitures, remarques, valide)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *
            `, [intervention_id, req.user.profil_id, heure_debut, heure_fin,
                statut_equipement, travaux_effectues, fournitures, remarques,
                valider || false]);
            rapport = rows[0];
        }

        // Champs spécifiques (clé-valeur)
        if (champs_specifiques && typeof champs_specifiques === 'object') {
            await db.query('DELETE FROM rapport_champs WHERE rapport_id = $1', [rapport.id]);
            for (const [cle, valeur] of Object.entries(champs_specifiques)) {
                if (valeur !== null && valeur !== undefined) {
                    await db.query(
                        'INSERT INTO rapport_champs (rapport_id, cle, valeur) VALUES ($1,$2,$3)',
                        [rapport.id, cle, String(valeur)]
                    );
                }
            }
        }

        // Si validé → mettre à jour le statut de l'intervention
        if (valider) {
            await db.query(
                "UPDATE interventions SET statut = 'terminee', updated_at = NOW() WHERE id = $1",
                [intervention_id]
            );
            broadcast('rapport:validated', { intervention_id, rapport_id: rapport.id });
        } else {
            broadcast('rapport:updated', { intervention_id, rapport_id: rapport.id });
        }

        res.status(existing[0] ? 200 : 201).json(rapport);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

// ── POST /api/rapports/:rapport_id/photos ── Upload photos
router.post('/:rapport_id/photos', auth, upload.array('photos', 10), async (req, res) => {
    try {
        const { rows: rapport } = await db.query(
            'SELECT * FROM rapports WHERE id = $1', [req.params.rapport_id]
        );
        if (!rapport[0]) return res.status(404).json({ error: 'Rapport introuvable' });
        if (rapport[0].valide && req.user.role === 'technicien')
            return res.status(403).json({ error: 'Rapport validé' });

        const uploadDir = path.join('uploads', 'photos');
        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

        const saved = [];
        for (const file of req.files) {
            const filename = `${uuidv4()}.webp`;
            const filepath = path.join(uploadDir, filename);

            // Compression avec Sharp → WebP, max 1200px, qualité 80
            await sharp(file.buffer)
                .resize({ width: 1200, height: 1200, fit: 'inside', withoutEnlargement: true })
                .webp({ quality: 80 })
                .toFile(filepath);

            const stats = fs.statSync(filepath);
            const { rows } = await db.query(`
                INSERT INTO rapport_photos (rapport_id, chemin, legende, taille_kb)
                VALUES ($1, $2, $3, $4) RETURNING *
            `, [req.params.rapport_id, `/uploads/photos/${filename}`,
                req.body.legende || null, Math.round(stats.size / 1024)]);

            saved.push(rows[0]);
        }

        res.status(201).json(saved);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erreur upload' });
    }
});

// ── POST /api/rapports/:rapport_id/signature ──
router.post('/:rapport_id/signature', auth, async (req, res) => {
    const { data_base64, signataire_nom } = req.body;
    if (!data_base64) return res.status(400).json({ error: 'Signature manquante' });

    try {
        // Sauvegarder aussi en fichier PNG
        const uploadDir = path.join('uploads', 'signatures');
        if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

        const base64Data = data_base64.replace(/^data:image\/png;base64,/, '');
        const filename   = `${uuidv4()}.png`;
        fs.writeFileSync(path.join(uploadDir, filename), base64Data, 'base64');

        // Upsert signature
        await db.query('DELETE FROM rapport_signatures WHERE rapport_id = $1', [req.params.rapport_id]);
        const { rows } = await db.query(`
            INSERT INTO rapport_signatures (rapport_id, data_base64, signataire_nom)
            VALUES ($1, $2, $3) RETURNING *
        `, [req.params.rapport_id, `/uploads/signatures/${filename}`, signataire_nom || null]);

        res.status(201).json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

// ── PATCH /api/rapports/:rapport_id (bureau/admin modification) ──
router.patch('/:rapport_id', auth, roles('admin', 'bureau'), async (req, res) => {
    const allowed = ['statut_equipement', 'travaux_effectues', 'fournitures', 'remarques', 'heure_debut', 'heure_fin'];
    const updates = [];
    const params  = [];

    Object.entries(req.body).forEach(([key, val]) => {
        if (allowed.includes(key)) {
            params.push(val);
            updates.push(`${key} = $${params.length}`);
        }
    });

    if (!updates.length) return res.status(400).json({ error: 'Aucun champ valide' });

    params.push(req.params.rapport_id);
    try {
        const { rows } = await db.query(`
            UPDATE rapports SET ${updates.join(', ')}, updated_at = NOW()
            WHERE id = $${params.length} RETURNING *
        `, params);

        // Champs spécifiques si fournis
        if (req.body.champs_specifiques) {
            await db.query('DELETE FROM rapport_champs WHERE rapport_id = $1', [req.params.rapport_id]);
            for (const [cle, valeur] of Object.entries(req.body.champs_specifiques)) {
                await db.query(
                    'INSERT INTO rapport_champs (rapport_id, cle, valeur) VALUES ($1,$2,$3)',
                    [req.params.rapport_id, cle, String(valeur)]
                );
            }
        }

        res.json(rows[0]);
    } catch (err) {
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

module.exports = router;
