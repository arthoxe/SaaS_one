const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db      = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// POST /api/auth/login
router.post('/login', async (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email et mot de passe requis' });
    try {
        const { rows } = await db.query('SELECT * FROM users WHERE email = $1 ', [email]);
        const user = rows[0];
        if (!user || !(await bcrypt.compare(password, user.password)))
            return res.status(401).json({ error: 'Identifiants incorrects' });

        let profil = null;
        if (user.role === 'technicien') {
            const r = await db.query('SELECT * FROM techniciens WHERE user_id = $1', [user.id]);
            profil = r.rows[0];
        } else if (['bureau', 'admin'].includes(user.role)) {
            const r = await db.query('SELECT * FROM chefs_equipe WHERE user_id = $1', [user.id]);
            profil = r.rows[0];
        } else {
            const r = await db.query('SELECT * FROM clients WHERE user_id = $1', [user.id]);
            profil = r.rows[0];
        }

        const accessToken = jwt.sign(
            { id: user.id, role: user.role, profil_id: profil?.id },
            process.env.JWT_SECRET,
            { expiresIn: '8h' }
        );
        const refreshToken = uuidv4();
        await db.query(
            'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES ($1, $2, $3)',
            [user.id, refreshToken, new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)]
        );
        await db.query('UPDATE users SET last_login = NOW() WHERE id = $1', [user.id]);

        res.json({
            access_token: accessToken, refresh_token: refreshToken,
            user: { id: user.id, email: user.email, role: user.role, nom: profil?.nom, prenom: profil?.prenom }
        });
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }); }
});

// POST /api/auth/create-chef — créer un compte chef d'équipe (admin seulement)
router.post('/create-chef', auth, roles('admin'), async (req, res) => {
    const { email, password, nom, prenom, telephone } = req.body;
    if (!email || !password || !nom || !prenom)
        return res.status(400).json({ error: 'Email, mot de passe, nom et prénom requis' });
    try {
        const hash = await bcrypt.hash(password, 12);
        const { rows: user } = await db.query(
            'INSERT INTO users (email, password, role) VALUES ($1, $2, $3) RETURNING *',
            [email, hash, 'bureau']
        );
        const { rows: chef } = await db.query(
            'INSERT INTO chefs_equipe (user_id, nom, prenom, telephone) VALUES ($1, $2, $3, $4) RETURNING *',
            [user[0].id, nom, prenom, telephone || null]
        );
        res.status(201).json({ ...chef[0], email: user[0].email });
    } catch (err) {
        if (err.code === '23505') return res.status(409).json({ error: 'Email déjà utilisé' });
        res.status(500).json({ error: 'Erreur serveur' });
    }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
    const { refresh_token } = req.body;
    if (!refresh_token) return res.status(400).json({ error: 'Refresh token manquant' });
    try {
        const { rows } = await db.query(
            `SELECT rt.*, u.role FROM refresh_tokens rt
             JOIN users u ON u.id = rt.user_id
             WHERE rt.token = $1 AND rt.expires_at > NOW()`,
            [refresh_token]
        );
        const rt = rows[0];
        if (!rt || !rt.actif) return res.status(401).json({ error: 'Token invalide' });
        const accessToken = jwt.sign({ id: rt.user_id, role: rt.role }, process.env.JWT_SECRET, { expiresIn: '8h' });
        res.json({ access_token: accessToken });
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// POST /api/auth/logout
router.post('/logout', auth, async (req, res) => {
    const { refresh_token } = req.body;
    if (refresh_token) await db.query('DELETE FROM refresh_tokens WHERE token = $1', [refresh_token]);
    res.json({ message: 'Déconnecté' });
});

module.exports = router;
