const router = require('express').Router();
const db = require('../utils/db');
const bcrypt = require('bcryptjs');
const { auth, roles } = require('../middleware/auth');

// GET / — sans ?tous=true : seulement ceux dans une équipe (pour planning/filtres)
//        — avec ?tous=true : tous (pour onglet Équipes)
router.get('/', auth, roles('admin','bureau'), async (req, res) => {
    try {
        const tous = req.query.tous === 'true'
        const query = tous
            ? 'SELECT t.*, u.email, u.last_login FROM techniciens t JOIN users u ON u.id=t.user_id ORDER BY t.nom ASC'
            : 'SELECT t.*, u.email, u.last_login FROM techniciens t JOIN users u ON u.id=t.user_id WHERE t.equipe_id IS NOT NULL ORDER BY t.nom ASC'
        const { rows } = await db.query(query)
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

router.post('/', auth, roles('admin','bureau'), async (req, res) => {
    const { email, password, nom, prenom, telephone } = req.body;
    if (!email||!password||!nom||!prenom) return res.status(400).json({error:'Champs requis manquants'});
    try {
        const hash = await bcrypt.hash(password, 12);
        const { rows: user } = await db.query(
            'INSERT INTO users (email,password,role) VALUES ($1,$2,$3) RETURNING *',
            [email, hash, 'technicien']
        );
        const { rows: tech } = await db.query(
            'INSERT INTO techniciens (user_id,nom,prenom,telephone) VALUES ($1,$2,$3,$4) RETURNING *',
            [user[0].id, nom, prenom, telephone||null]
        );
        res.status(201).json({...tech[0], email: user[0].email});
    } catch(err) {
        if (err.code==='23505') return res.status(409).json({error:'Email déjà utilisé'});
        res.status(500).json({error:'Erreur serveur'});
    }
});

router.patch('/:id', auth, roles('admin','bureau'), async (req, res) => {
    try {
        if (req.body.chef_id !== undefined) {
            const chefId = req.body.chef_id || null
            if (chefId) {
                let { rows: equipes } = await db.query('SELECT id FROM equipes WHERE chef_id=$1 LIMIT 1', [chefId])
                let equipeId
                if (equipes.length === 0) {
                    const { rows: newEq } = await db.query(
                        "INSERT INTO equipes (chef_id, nom) VALUES ($1, 'Equipe') RETURNING id",
                        [chefId]
                    )
                    equipeId = newEq[0].id
                } else {
                    equipeId = equipes[0].id
                }
                await db.query('UPDATE techniciens SET equipe_id=$1 WHERE id=$2', [equipeId, req.params.id])
            } else {
                await db.query('UPDATE techniciens SET equipe_id=NULL WHERE id=$1', [req.params.id])
            }
        }
        const allowed = ['nom','prenom','telephone','actif'];
        const updates=[]; const params=[];
        Object.entries(req.body).forEach(([k,v])=>{ if(allowed.includes(k)){params.push(v);updates.push(`${k}=$${params.length}`);}});
        if (updates.length) {
            params.push(req.params.id);
            await db.query(`UPDATE techniciens SET ${updates.join(',')} WHERE id=$${params.length}`, params);
        }
        const { rows } = await db.query('SELECT * FROM techniciens WHERE id=$1', [req.params.id])
        res.json(rows[0])
    } catch(err) { console.error(err); res.status(500).json({error:'Erreur serveur'}); }
});

router.delete('/:id', auth, roles('admin'), async (req, res) => {
    try {
        const { rows: t } = await db.query('SELECT user_id FROM techniciens WHERE id=$1', [req.params.id])
        if (!t[0]) return res.status(404).json({error:'Technicien introuvable'})
        await db.query('DELETE FROM techniciens WHERE id=$1', [req.params.id])
        await db.query('DELETE FROM users WHERE id=$1', [t[0].user_id])
        res.json({ok:true})
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

module.exports = router;
