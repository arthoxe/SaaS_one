const jwt = require('jsonwebtoken');

// Vérifie le token JWT
const auth = (req, res, next) => {
    const header = req.headers.authorization;
    if (!header?.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Token manquant' });
    }
    const token = header.split(' ')[1];
    try {
        req.user = jwt.verify(token, process.env.JWT_SECRET);
        next();
    } catch (err) {
        return res.status(401).json({ error: 'Token invalide ou expiré' });
    }
};

// Vérifie les rôles autorisés
const roles = (...allowed) => (req, res, next) => {
    if (!allowed.includes(req.user.role)) {
        return res.status(403).json({ error: 'Accès refusé' });
    }
    next();
};

module.exports = { auth, roles };
