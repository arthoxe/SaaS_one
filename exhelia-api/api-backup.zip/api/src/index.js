require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const { createServer } = require('http');
const { setupWebSocket } = require('./utils/websocket');

const app    = express();
app.set('trust proxy', 1);
const server = createServer(app);

// ── WebSocket (suivi temps réel pour le bureau) ──
setupWebSocket(server);

// ── Sécurité ──
app.use(helmet());
app.use(cors({
    origin: process.env.ALLOWED_ORIGINS?.split(',') || '*',
    credentials: true
}));

// ── Rate limiting ──
const limiter = rateLimit({
    windowMs: 60 * 1000,        // 1 minute
    max: 100,                    // 100 requêtes max
    message: { error: 'Trop de requêtes, réessayez dans une minute.' }
});
app.use('/api', limiter);

// Auth plus strict
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,   // 15 minutes
    max: 10,
    message: { error: 'Trop de tentatives de connexion.' }
});
app.use('/api/auth', authLimiter);

// ── Parsing ──
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Fichiers statiques (photos uploadées) ──
app.use('/uploads', express.static('uploads'));

// ── Routes ──
app.use('/api/auth',          require('./routes/auth'));
app.use('/api/users',         require('./routes/users'));
app.use('/api/techniciens',   require('./routes/techniciens'));
app.use('/api/clients',       require('./routes/clients'));
app.use('/api/logements',     require('./routes/logements'));
app.use('/api/equipements',   require('./routes/equipements'));
app.use('/api/interventions', require('./routes/interventions'));
app.use('/api/rapports',      require('./routes/rapports'));
app.use('/api/recherche',     require('./routes/recherche'));
app.use('/api/capteurs',      require('./routes/capteurs'));
app.use('/api/export',        require('./routes/export'));

app.use('/api/equipes', require('./routes/equipes'));
app.use('/api/chefs', require('./routes/chefs'));

// ── Health check ──
app.get('/health', (req, res) => res.json({ status: 'ok', timestamp: new Date() }));

// ── 404 ──
app.use((req, res) => res.status(404).json({ error: 'Route introuvable' }));

// ── Erreurs globales ──
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(err.status || 500).json({
        error: process.env.NODE_ENV === 'production'
            ? 'Erreur serveur'
            : err.message
    });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`✅ API Exhelia démarrée sur le port ${PORT}`);
});
