const router = require('express').Router();
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// GET /api/equipes — liste des équipes (admin voit tout, bureau voit la sienne)
router.get('/', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        let query, params = [];
        if (req.user.role === 'bureau') {
            const { rows: chef } = await db.query('SELECT id FROM chefs_equipe WHERE user_id = $1', [req.user.id]);
            params.push(chef[0]?.id);
            query = `
                SELECT e.*, 
                    json_agg(json_build_object('id',t.id,'nom',t.nom,'prenom',t.prenom,'telephone',t.telephone,'email',u.email)) FILTER (WHERE t.id IS NOT NULL) AS techniciens
                FROM equipes e
                LEFT JOIN techniciens t ON t.equipe_id = e.id
                LEFT JOIN users u ON u.id = t.user_id
                WHERE e.chef_id = $1
                GROUP BY e.id
            `;
        } else {
            query = `
                SELECT e.*,
                    ce.nom AS chef_nom, ce.prenom AS chef_prenom,
                    json_agg(json_build_object('id',t.id,'nom',t.nom,'prenom',t.prenom,'telephone',t.telephone,'email',u.email)) FILTER (WHERE t.id IS NOT NULL) AS techniciens
                FROM equipes e
                LEFT JOIN chefs_equipe ce ON ce.id = e.chef_id
                LEFT JOIN techniciens t ON t.equipe_id = e.id
                LEFT JOIN users u ON u.id = t.user_id
                GROUP BY e.id, ce.nom, ce.prenom
                ORDER BY e.created_at ASC
            `;
        }
        const { rows } = await db.query(query, params);
        res.json(rows);
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }); }
});

// GET /api/equipes/techniciens-libres — techniciens sans équipe
router.get('/techniciens-libres', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT t.*, u.email FROM techniciens t
            JOIN users u ON u.id = t.user_id
            WHERE t.equipe_id IS NULL 
            ORDER BY t.nom ASC
        `);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// POST /api/equipes — créer une équipe
router.post('/', auth, roles('admin', 'bureau'), async (req, res) => {
    const { nom } = req.body;
    if (!nom) return res.status(400).json({ error: 'Nom requis' });
    try {
        const { rows: chef } = await db.query('SELECT id FROM chefs_equipe WHERE user_id = $1', [req.user.id]);
        const chef_id = req.user.role === 'admin' ? (req.body.chef_id || chef[0]?.id) : chef[0]?.id;
        const { rows } = await db.query(
            'INSERT INTO equipes (chef_id, nom) VALUES ($1, $2) RETURNING *',
            [chef_id, nom]
        );
        res.status(201).json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// PATCH /api/equipes/:equipe_id/techniciens/:tech_id — assigner technicien à équipe
router.patch('/:equipe_id/techniciens/:tech_id', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        const { rows } = await db.query(
            'UPDATE techniciens SET equipe_id = $1 WHERE id = $2 RETURNING *',
            [req.params.equipe_id, req.params.tech_id]
        );
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

// DELETE /api/equipes/:equipe_id/techniciens/:tech_id — retirer technicien de l'équipe
router.delete('/:equipe_id/techniciens/:tech_id', auth, roles('admin', 'bureau'), async (req, res) => {
    try {
        await db.query('UPDATE techniciens SET equipe_id = NULL WHERE id = $1 AND equipe_id = $2',
            [req.params.tech_id, req.params.equipe_id]);
        res.json({ message: 'Technicien retiré' });
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
