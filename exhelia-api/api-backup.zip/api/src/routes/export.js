const router = require('express').Router();
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// ── GET /api/export/interventions?format=csv&date_debut=...&date_fin=... ──
router.get('/interventions', auth, roles('admin', 'bureau'), async (req, res) => {
    const { format = 'csv', date_debut, date_fin, technicien_id } = req.query;
    const params = [];
    const conditions = ['1=1'];

    if (date_debut) { params.push(date_debut); conditions.push(`i.date_prevue >= $${params.length}`); }
    if (date_fin)   { params.push(date_fin);   conditions.push(`i.date_prevue <= $${params.length}`); }
    if (technicien_id) { params.push(technicien_id); conditions.push(`i.technicien_id = $${params.length}`); }

    try {
        const { rows } = await db.query(`
            SELECT
                i.date_prevue, i.heure_prevue, i.type, i.statut,
                l.adresse, l.ville, l.code_postal, l.etage, l.numero_porte, l.nom_locataire,
                c.nom AS client_nom, c.prenom AS client_prenom,
                t.nom AS tech_nom, t.prenom AS tech_prenom,
                r.heure_debut, r.heure_fin, r.statut_equipement, r.travaux_effectues, r.remarques
            FROM interventions i
            JOIN logements l ON l.id = i.logement_id
            JOIN clients c ON c.id = l.client_id
            LEFT JOIN techniciens t ON t.id = i.technicien_id
            LEFT JOIN rapports r ON r.intervention_id = i.id
            WHERE ${conditions.join(' AND ')}
            ORDER BY i.date_prevue DESC
        `, params);

        if (format === 'csv') {
            const csvSanitize = (v) => {
                v = String(v ?? '');
                if (v && ['=','@','+','-'].includes(v[0])) v = "'" + v;
                return `"${v.replace(/"/g, '""')}"`;
            };

            const headers = ['Date','Heure','Type','Statut','Adresse','Ville','CP','Étage','Porte','Locataire','Client','Technicien','Début','Fin','État équipement','Travaux','Remarques'];
            const csvRows = rows.map(r => [
                r.date_prevue ? new Date(r.date_prevue).toLocaleDateString('fr-FR') : '',
                r.heure_prevue || '',
                r.type || '',
                r.statut || '',
                r.adresse || '',
                r.ville || '',
                r.code_postal || '',
                r.etage || '',
                r.numero_porte || '',
                r.nom_locataire || '',
                `${r.client_nom || ''} ${r.client_prenom || ''}`.trim(),
                `${r.tech_nom || ''} ${r.tech_prenom || ''}`.trim(),
                r.heure_debut ? new Date(r.heure_debut).toLocaleTimeString('fr-FR') : '',
                r.heure_fin   ? new Date(r.heure_fin).toLocaleTimeString('fr-FR') : '',
                r.statut_equipement || '',
                r.travaux_effectues || '',
                r.remarques || ''
            ].map(csvSanitize).join(';'));

            const csv = '\uFEFF' + headers.map(h => `"${h}"`).join(';') + '\n' + csvRows.join('\n');

            res.setHeader('Content-Type', 'text/csv; charset=utf-8');
            res.setHeader('Content-Disposition', `attachment; filename="interventions-${new Date().toISOString().split('T')[0]}.csv"`);
            return res.send(csv);
        }

        // JSON par défaut
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erreur export' });
    }
});

module.exports = router;
