// routes/capteurs.js
const router = require('express').Router();
const db = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// Liste capteurs d'un équipement
router.get('/', auth, async (req, res) => {
    const { equipement_id } = req.query;
    if (!equipement_id) return res.status(400).json({error:'equipement_id requis'});
    try {
        const {rows} = await db.query('SELECT * FROM capteurs WHERE equipement_id=$1 AND actif=TRUE',[equipement_id]);
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

// Mesures d'un capteur sur une période
router.get('/:capteur_id/mesures', auth, async (req, res) => {
    const { debut, fin, limit=1000 } = req.query;
    const params = [req.params.capteur_id];
    const conditions = ['capteur_id=$1'];
    if (debut) { params.push(debut); conditions.push(`timestamp>=$${params.length}`); }
    if (fin)   { params.push(fin);   conditions.push(`timestamp<=$${params.length}`); }
    params.push(limit);
    try {
        const {rows} = await db.query(
            `SELECT valeur, timestamp FROM mesures WHERE ${conditions.join(' AND ')} ORDER BY timestamp DESC LIMIT $${params.length}`,
            params
        );
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

// Ingest mesure(s) depuis capteur IoT
router.post('/:capteur_id/mesures', async (req, res) => {
    // Endpoint non authentifié via JWT mais via API key
    const apiKey = req.headers['x-api-key'];
    if (apiKey !== process.env.SENSOR_API_KEY)
        return res.status(401).json({error:'Clé API invalide'});

    const { valeur, timestamp } = req.body;
    if (valeur === undefined) return res.status(400).json({error:'valeur requis'});
    try {
        await db.query(
            'INSERT INTO mesures (capteur_id, valeur, timestamp) VALUES ($1,$2,$3)',
            [req.params.capteur_id, valeur, timestamp || new Date()]
        );
        res.status(201).json({ok:true});
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

// Stats agrégées (pour l'extranet pro)
router.get('/:capteur_id/stats', auth, async (req, res) => {
    const { periode = '7d' } = req.query;
    const intervals = { '24h':'1 day','7d':'7 days','30d':'30 days','1y':'1 year' };
    const interval = intervals[periode] || '7 days';
    try {
        const {rows} = await db.query(`
            SELECT
                DATE_TRUNC('hour', timestamp) AS heure,
                AVG(valeur)::NUMERIC(10,2) AS moyenne,
                MIN(valeur) AS min,
                MAX(valeur) AS max,
                COUNT(*) AS nb_mesures
            FROM mesures
            WHERE capteur_id=$1 AND timestamp >= NOW() - INTERVAL '${interval}'
            GROUP BY heure ORDER BY heure ASC
        `, [req.params.capteur_id]);
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

module.exports = router;
