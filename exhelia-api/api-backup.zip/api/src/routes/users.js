// routes/users.js
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const db      = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

// Mon profil
router.get('/me', auth, async (req, res) => {
    try {
        const { rows } = await db.query(
            'SELECT id, email, role, created_at, last_login FROM users WHERE id=$1', [req.user.id]
        );
        res.json(rows[0]);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

// Changer mot de passe
router.patch('/me/password', auth, async (req, res) => {
    const { current, nouveau } = req.body;
    if (!current||!nouveau||nouveau.length<8)
        return res.status(400).json({error:'Mot de passe actuel et nouveau (8 car. min) requis'});
    try {
        const { rows } = await db.query('SELECT password FROM users WHERE id=$1', [req.user.id]);
        if (!(await bcrypt.compare(current, rows[0].password)))
            return res.status(401).json({error:'Mot de passe actuel incorrect'});
        const hash = await bcrypt.hash(nouveau, 12);
        await db.query('UPDATE users SET password=$1 WHERE id=$2', [hash, req.user.id]);
        res.json({message:'Mot de passe mis à jour'});
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

// Modifier profil (nom, prenom)
router.patch('/me', auth, async (req, res) => {
    const { nom, prenom } = req.body
    try {
        // Mettre à jour dans la bonne table selon le rôle
        if (req.user.role === 'admin' || req.user.role === 'bureau') {
            await db.query(
                'UPDATE chefs_equipe SET nom=$1, prenom=$2 WHERE user_id=$3',
                [nom, prenom, req.user.id]
            )
        } else if (req.user.role === 'technicien') {
            await db.query(
                'UPDATE techniciens SET nom=$1, prenom=$2 WHERE user_id=$3',
                [nom, prenom, req.user.id]
            )
        }
        res.json({ message: 'Profil mis à jour', nom, prenom })
    } catch(err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }) }
})

// Upload photo de profil (base64)
router.patch('/me/photo', auth, async (req, res) => {
    const { photo } = req.body
    if (!photo) return res.status(400).json({ error: 'Photo requise' })
    try {
        await db.query('UPDATE users SET photo=$1 WHERE id=$2', [photo, req.user.id])
        res.json({ message: 'Photo mise à jour' })
    } catch(err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }) }
})

module.exports = router;
