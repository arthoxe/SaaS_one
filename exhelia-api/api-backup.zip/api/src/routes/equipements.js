// routes/equipements.js
const router = require('express').Router();
const db = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

router.get('/', auth, async (req, res) => {
    const { logement_id } = req.query;
    if (!logement_id) return res.status(400).json({error:'logement_id requis'});
    try {
        const {rows} = await db.query('SELECT * FROM equipements WHERE logement_id=$1 AND actif=TRUE ORDER BY type ASC',[logement_id]);
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

router.post('/', auth, roles('admin','bureau'), async (req, res) => {
    const {logement_id, type, marque, modele, numero_serie, date_install} = req.body;
    if (!logement_id||!type) return res.status(400).json({error:'logement_id et type requis'});
    try {
        const {rows} = await db.query(
            'INSERT INTO equipements (logement_id,type,marque,modele,numero_serie,date_install) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',
            [logement_id,type,marque||null,modele||null,numero_serie||null,date_install||null]
        );
        res.status(201).json(rows[0]);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

module.exports = router;
