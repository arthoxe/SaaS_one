const router = require('express').Router()
const db     = require('../utils/db')
const { auth, roles } = require('../middleware/auth')

// GET /api/chefs — avec techniciens de chaque equipe
router.get('/', auth, roles('admin', 'bureau'), async (req, res) => {
  try {
    const { rows: chefs } = await db.query(`
      SELECT ce.*, u.email, u.last_login
      FROM chefs_equipe ce
      JOIN users u ON u.id = ce.user_id
      
      ORDER BY ce.nom ASC
    `)
    const enriched = await Promise.all(chefs.map(async (chef) => {
      const { rows: techs } = await db.query(`
        SELECT t.*, u2.email, u2.last_login
        FROM techniciens t
        JOIN users u2 ON u2.id = t.user_id
        LEFT JOIN equipes e ON e.id = t.equipe_id
        WHERE e.chef_id = $1 
        ORDER BY t.nom ASC
      `, [chef.id])
      return { ...chef, techniciens: techs }
    }))
    res.json(enriched)
  } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }) }
})

// DELETE /api/chefs/:id — suppression definitive
router.delete('/:id', auth, roles('admin'), async (req, res) => {
  try {
    const { rows } = await db.query('SELECT user_id FROM chefs_equipe WHERE id = $1', [req.params.id])
    if (!rows[0]) return res.status(404).json({ error: 'Chef introuvable' })
    await db.query('DELETE FROM chefs_equipe WHERE id = $1', [req.params.id])
    res.json({ message: 'Chef supprime' })
  } catch (err) { res.status(500).json({ error: 'Erreur serveur' }) }
})

module.exports = router
