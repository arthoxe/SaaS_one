// ═══════════════════════════════════════════════
// routes/logements.js
// ═══════════════════════════════════════════════
const router = require('express').Router();
const db     = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

router.get('/', auth, roles('admin', 'bureau'), async (req, res) => {
    const { client_id, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;
    try {
        const params = client_id ? [client_id, limit, offset] : [limit, offset];
        const where  = client_id ? 'WHERE l.client_id = $1' : '';
        const { rows } = await db.query(`
            SELECT l.*, c.nom AS client_nom, c.prenom AS client_prenom, c.type AS client_type
            FROM logements l JOIN clients c ON c.id = l.client_id
            ${where} ORDER BY l.adresse ASC
            LIMIT $${client_id ? 2 : 1} OFFSET $${client_id ? 3 : 2}
        `, params);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.get('/:id', auth, async (req, res) => {
    try {
        const { rows } = await db.query(`
            SELECT l.*, c.nom AS client_nom, c.prenom AS client_prenom
            FROM logements l JOIN clients c ON c.id = l.client_id
            WHERE l.id = $1
        `, [req.params.id]);

        // Client ne peut voir que ses logements
        if (req.user.role !== 'admin' && req.user.role !== 'bureau') {
            const { rows: client } = await db.query(
                'SELECT id FROM clients WHERE user_id = $1', [req.user.id]
            );
            if (rows[0]?.client_id !== client[0]?.id)
                return res.status(403).json({ error: 'Accès refusé' });
        }

        if (!rows[0]) return res.status(404).json({ error: 'Logement introuvable' });
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.post('/', auth, roles('admin', 'bureau'), async (req, res) => {
    const { client_id, adresse, complement, ville, code_postal, etage, numero_porte, digicode, telephone_loc, nom_locataire } = req.body;
    if (!client_id || !adresse || !ville || !code_postal)
        return res.status(400).json({ error: 'Champs obligatoires manquants' });
    try {
        const { rows } = await db.query(`
            INSERT INTO logements (client_id, adresse, complement, ville, code_postal, etage, numero_porte, digicode, telephone_loc, nom_locataire)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *
        `, [client_id, adresse, complement||null, ville, code_postal, etage||null, numero_porte||null, digicode||null, telephone_loc||null, nom_locataire||null]);
        res.status(201).json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

router.patch('/:id', auth, roles('admin', 'bureau'), async (req, res) => {
    const allowed = ['adresse','complement','ville','code_postal','etage','numero_porte','digicode','telephone_loc','nom_locataire','actif'];
    const updates = []; const params = [];
    Object.entries(req.body).forEach(([k,v]) => { if (allowed.includes(k)) { params.push(v); updates.push(`${k}=$${params.length}`); } });
    if (!updates.length) return res.status(400).json({ error: 'Aucun champ valide' });
    params.push(req.params.id);
    try {
        const { rows } = await db.query(`UPDATE logements SET ${updates.join(',')} WHERE id=$${params.length} RETURNING *`, params);
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: 'Erreur serveur' }); }
});

module.exports = router;
