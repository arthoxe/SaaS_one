-- ═══════════════════════════════════════════════
--  EXHELIA — Schéma PostgreSQL complet
-- ═══════════════════════════════════════════════

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- ───────────────────────────────────────────────
-- 1. UTILISATEURS & RÔLES
-- ───────────────────────────────────────────────
CREATE TYPE user_role AS ENUM ('admin', 'bureau', 'technicien', 'particulier', 'bailleur', 'pro');

CREATE TABLE users (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email       VARCHAR(150) UNIQUE NOT NULL,
    password    VARCHAR(255) NOT NULL,           -- bcrypt hash
    role        user_role NOT NULL,
    actif       BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT NOW(),
    last_login  TIMESTAMP
);

-- ───────────────────────────────────────────────
-- 2. PROFILS PAR RÔLE
-- ───────────────────────────────────────────────
CREATE TABLE techniciens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100) NOT NULL,
    telephone   VARCHAR(20),
    photo       VARCHAR(255),                    -- chemin fichier
    actif       BOOLEAN DEFAULT TRUE,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE chefs_equipe (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100) NOT NULL,
    telephone   VARCHAR(20),
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE clients (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    type        VARCHAR(20) NOT NULL CHECK (type IN ('particulier', 'bailleur', 'pro')),
    nom         VARCHAR(100) NOT NULL,
    prenom      VARCHAR(100),                    -- null pour bailleur/pro
    raison_sociale VARCHAR(150),                 -- pour bailleur/pro
    siret       VARCHAR(20),
    telephone   VARCHAR(20),
    created_at  TIMESTAMP DEFAULT NOW()
);

-- ───────────────────────────────────────────────
-- 3. PATRIMOINE
-- ───────────────────────────────────────────────
CREATE TABLE logements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id       UUID REFERENCES clients(id) ON DELETE CASCADE,
    adresse         VARCHAR(200) NOT NULL,
    complement      VARCHAR(100),
    ville           VARCHAR(100) NOT NULL,
    code_postal     VARCHAR(10) NOT NULL,
    etage           VARCHAR(20),
    numero_porte    VARCHAR(20),
    digicode        VARCHAR(50),
    telephone_loc   VARCHAR(20),                 -- téléphone locataire (pour bailleurs)
    nom_locataire   VARCHAR(150),
    actif           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT NOW(),
    -- Full Text Search
    search_vector   TSVECTOR
);

-- Trigger pour mise à jour auto du vecteur FTS
CREATE OR REPLACE FUNCTION logements_search_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('french',
        unaccent(COALESCE(NEW.adresse, '')) || ' ' ||
        unaccent(COALESCE(NEW.ville, '')) || ' ' ||
        unaccent(COALESCE(NEW.code_postal, '')) || ' ' ||
        unaccent(COALESCE(NEW.nom_locataire, ''))
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER logements_search_trigger
    BEFORE INSERT OR UPDATE ON logements
    FOR EACH ROW EXECUTE FUNCTION logements_search_update();

-- Index FTS + trigram
CREATE INDEX idx_logements_fts    ON logements USING GIN(search_vector);
CREATE INDEX idx_logements_trgm   ON logements USING GIN(adresse gin_trgm_ops);
CREATE INDEX idx_logements_client ON logements(client_id);

-- ───────────────────────────────────────────────
-- 4. ÉQUIPEMENTS
-- ───────────────────────────────────────────────
CREATE TYPE equipement_type AS ENUM (
    'vmc', 'pac', 'solaire', 'chaudiere', 'ventilation', 'climatisation', 'autre'
);

CREATE TABLE equipements (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    logement_id     UUID REFERENCES logements(id) ON DELETE CASCADE,
    type            equipement_type NOT NULL,
    marque          VARCHAR(100),
    modele          VARCHAR(100),
    numero_serie    VARCHAR(100),
    date_install    DATE,
    derniere_inter  DATE,
    actif           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_equipements_logement ON equipements(logement_id);
CREATE INDEX idx_equipements_type     ON equipements(type);

-- ───────────────────────────────────────────────
-- 5. INTERVENTIONS
-- ───────────────────────────────────────────────
CREATE TYPE intervention_statut AS ENUM (
    'planifiee', 'en_cours', 'terminee', 'annulee'
);

CREATE TABLE interventions (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    logement_id     UUID REFERENCES logements(id) ON DELETE RESTRICT,
    equipement_id   UUID REFERENCES equipements(id) ON DELETE SET NULL,
    technicien_id   UUID REFERENCES techniciens(id) ON DELETE SET NULL,
    chef_id         UUID REFERENCES chefs_equipe(id) ON DELETE SET NULL,
    type            equipement_type NOT NULL,
    statut          intervention_statut DEFAULT 'planifiee',
    date_prevue     DATE NOT NULL,
    heure_prevue    TIME,
    duree_prevue    INTEGER,                      -- minutes
    notes_bureau    TEXT,
    urgente         BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT NOW(),
    updated_at      TIMESTAMP DEFAULT NOW(),
    -- Full Text Search
    search_vector   TSVECTOR
);

CREATE OR REPLACE FUNCTION interventions_search_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.search_vector := to_tsvector('french',
        unaccent(COALESCE(NEW.notes_bureau, ''))
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER interventions_search_trigger
    BEFORE INSERT OR UPDATE ON interventions
    FOR EACH ROW EXECUTE FUNCTION interventions_search_update();

CREATE INDEX idx_interventions_technicien ON interventions(technicien_id);
CREATE INDEX idx_interventions_date       ON interventions(date_prevue);
CREATE INDEX idx_interventions_statut     ON interventions(statut);
CREATE INDEX idx_interventions_logement   ON interventions(logement_id);
CREATE INDEX idx_interventions_fts        ON interventions USING GIN(search_vector);

-- ───────────────────────────────────────────────
-- 6. RAPPORTS
-- ───────────────────────────────────────────────
CREATE TABLE rapports (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    intervention_id     UUID REFERENCES interventions(id) ON DELETE RESTRICT UNIQUE,
    technicien_id       UUID REFERENCES techniciens(id) ON DELETE SET NULL,
    heure_debut         TIMESTAMP,
    heure_fin           TIMESTAMP,
    statut_equipement   VARCHAR(50),             -- bon_etat / defaillant / remplace
    travaux_effectues   TEXT,
    fournitures         TEXT,
    remarques           TEXT,
    valide              BOOLEAN DEFAULT FALSE,   -- true = technicien a soumis, plus modifiable par lui
    created_at          TIMESTAMP DEFAULT NOW(),
    updated_at          TIMESTAMP DEFAULT NOW()
);

-- Champs dynamiques selon type d'intervention (clé-valeur flexible)
CREATE TABLE rapport_champs (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rapport_id  UUID REFERENCES rapports(id) ON DELETE CASCADE,
    cle         VARCHAR(100) NOT NULL,           -- ex: "pression_bar", "debit_vmc"
    valeur      TEXT,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_rapport_champs_rapport ON rapport_champs(rapport_id);
CREATE INDEX idx_rapports_intervention  ON rapports(intervention_id);
CREATE INDEX idx_rapports_technicien    ON rapports(technicien_id);

-- ───────────────────────────────────────────────
-- 7. PHOTOS & SIGNATURES
-- ───────────────────────────────────────────────
CREATE TABLE rapport_photos (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rapport_id  UUID REFERENCES rapports(id) ON DELETE CASCADE,
    chemin      VARCHAR(255) NOT NULL,           -- /uploads/photos/uuid.webp
    legende     VARCHAR(200),
    taille_kb   INTEGER,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE TABLE rapport_signatures (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    rapport_id      UUID REFERENCES rapports(id) ON DELETE CASCADE UNIQUE,
    data_base64     TEXT NOT NULL,               -- canvas PNG base64
    signataire_nom  VARCHAR(150),
    signed_at       TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_photos_rapport    ON rapport_photos(rapport_id);

-- ───────────────────────────────────────────────
-- 8. CAPTEURS & ANALYTICS (module pro)
-- ───────────────────────────────────────────────
CREATE TABLE capteurs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipement_id   UUID REFERENCES equipements(id) ON DELETE CASCADE,
    nom             VARCHAR(100) NOT NULL,
    type            VARCHAR(50),                 -- temperature / pression / consommation
    unite           VARCHAR(20),                 -- °C / bar / kWh
    actif           BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT NOW()
);

CREATE TABLE mesures (
    id          BIGSERIAL PRIMARY KEY,
    capteur_id  UUID REFERENCES capteurs(id) ON DELETE CASCADE,
    valeur      NUMERIC(12, 4) NOT NULL,
    timestamp   TIMESTAMP NOT NULL DEFAULT NOW()
);

-- Index temporel pour les séries de mesures
CREATE INDEX idx_mesures_capteur_time ON mesures(capteur_id, timestamp DESC);

CREATE TABLE calculs_eco (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    equipement_id   UUID REFERENCES equipements(id) ON DELETE CASCADE,
    periode_debut   DATE NOT NULL,
    periode_fin     DATE NOT NULL,
    conso_kwh       NUMERIC(10, 2),
    economies_eur   NUMERIC(10, 2),
    co2_evite_kg    NUMERIC(10, 2),
    computed_at     TIMESTAMP DEFAULT NOW()
);

-- ───────────────────────────────────────────────
-- 9. REFRESH TOKENS (auth)
-- ───────────────────────────────────────────────
CREATE TABLE refresh_tokens (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id     UUID REFERENCES users(id) ON DELETE CASCADE,
    token       VARCHAR(500) UNIQUE NOT NULL,
    expires_at  TIMESTAMP NOT NULL,
    created_at  TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_refresh_tokens_user    ON refresh_tokens(user_id);
CREATE INDEX idx_refresh_tokens_token   ON refresh_tokens(token);

-- ───────────────────────────────────────────────
-- 10. RECHERCHE GLOBALE (vue matérialisée)
-- ───────────────────────────────────────────────
-- Vue pour la recherche globale du chef d'équipe (logements + clients + interventions)
CREATE MATERIALIZED VIEW recherche_globale AS
    SELECT
        l.id,
        'logement'::TEXT AS type,
        l.adresse || ', ' || l.ville AS titre,
        c.nom || ' ' || COALESCE(c.prenom, '') AS client,
        l.search_vector
    FROM logements l
    JOIN clients c ON c.id = l.client_id
UNION ALL
    SELECT
        i.id,
        'intervention'::TEXT AS type,
        'Inter. du ' || TO_CHAR(i.date_prevue, 'DD/MM/YYYY') AS titre,
        i.type::TEXT AS client,
        i.search_vector
    FROM interventions i;

CREATE INDEX idx_recherche_globale_fts ON recherche_globale USING GIN(search_vector);

-- Rafraîchir la vue (à appeler après INSERT/UPDATE important)
-- REFRESH MATERIALIZED VIEW CONCURRENTLY recherche_globale;
