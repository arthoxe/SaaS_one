const { WebSocketServer } = require('ws');
const jwt = require('jsonwebtoken');

let wss;
const clients = new Map(); // userId → ws

function setupWebSocket(server) {
    wss = new WebSocketServer({ server, path: '/ws' });

    wss.on('connection', (ws, req) => {
        // Authentification via token dans l'URL
        const url    = new URL(req.url, 'http://localhost');
        const token  = url.searchParams.get('token');

        try {
            const user = jwt.verify(token, process.env.JWT_SECRET);
            ws.userId  = user.id;
            ws.role    = user.role;
            clients.set(user.id, ws);

            ws.send(JSON.stringify({ type: 'connected', message: 'WebSocket connecté' }));

            ws.on('close', () => clients.delete(user.id));
            ws.on('error', () => clients.delete(user.id));
        } catch {
            ws.close(1008, 'Token invalide');
        }
    });

    console.log('✅ WebSocket initialisé');
}

// Diffuser un événement à tous les rôles bureau/admin
function broadcast(type, data) {
    if (!wss) return;
    const message = JSON.stringify({ type, data, timestamp: new Date() });

    clients.forEach((ws, userId) => {
        if (ws.readyState === 1 && ['admin', 'bureau'].includes(ws.role)) {
            ws.send(message);
        }
    });
}

// Envoyer à un utilisateur spécifique
function sendTo(userId, type, data) {
    const ws = clients.get(userId);
    if (ws?.readyState === 1) {
        ws.send(JSON.stringify({ type, data, timestamp: new Date() }));
    }
}

module.exports = { setupWebSocket, broadcast, sendTo };
