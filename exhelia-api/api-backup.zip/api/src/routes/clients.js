// routes/clients.js
const router = require('express').Router();
const db = require('../utils/db');
const { auth, roles } = require('../middleware/auth');

router.get('/', auth, roles('admin','bureau'), async (req, res) => {
    const { type, page=1, limit=50 } = req.query;
    const offset = (page-1)*limit;
    try {
        const params = type ? [type, limit, offset] : [limit, offset];
        const where  = type ? 'WHERE c.type=$1' : '';
        const { rows } = await db.query(
            `SELECT c.*, u.email, u.last_login FROM clients c JOIN users u ON u.id=c.user_id ${where} ORDER BY c.nom ASC LIMIT $${type?2:1} OFFSET $${type?3:2}`,
            params
        );
        res.json(rows);
    } catch(err) { res.status(500).json({error:'Erreur serveur'}); }
});

router.post('/', auth, roles('admin','bureau'), async (req, res) => {
    const bcrypt = require('bcryptjs');
    const { email, password, type, nom, prenom, raison_sociale, siret, telephone } = req.body;
    if (!email||!password||!type||!nom) return res.status(400).json({error:'Champs requis manquants'});
    try {
        const hash = await bcrypt.hash(password, 12);
        const { rows: user } = await db.query(
            'INSERT INTO users (email,password,role) VALUES ($1,$2,$3) RETURNING *',
            [email, hash, type === 'particulier' ? 'particulier' : type === 'bailleur' ? 'bailleur' : 'pro']
        );
        const { rows: client } = await db.query(
            'INSERT INTO clients (user_id,type,nom,prenom,raison_sociale,siret,telephone) VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING *',
            [user[0].id, type, nom, prenom||null, raison_sociale||null, siret||null, telephone||null]
        );
        res.status(201).json({...client[0], email: user[0].email});
    } catch(err) {
        if (err.code==='23505') return res.status(409).json({error:'Email déjà utilisé'});
        res.status(500).json({error:'Erreur serveur'});
    }
});

router.delete('/:id', auth, roles('admin'), async (req, res) => {
    try {
        const { rows } = await db.query('SELECT id, user_id FROM clients WHERE id = $1', [req.params.id])
        if (!rows[0]) return res.status(404).json({ error: 'Client introuvable' })
        // Supprimer interventions liées aux logements du client
        await db.query('DELETE FROM interventions WHERE logement_id IN (SELECT id FROM logements WHERE client_id = $1)', [req.params.id])
        // Supprimer les logements
        await db.query('DELETE FROM logements WHERE client_id = $1', [req.params.id])
        // Supprimer le client
        await db.query('DELETE FROM clients WHERE id = $1', [req.params.id])
        // Supprimer le user lié
        if (rows[0].user_id) await db.query('DELETE FROM users WHERE id = $1', [rows[0].user_id])
        res.json({ message: 'Client supprime' })
    } catch (err) { console.error(err); res.status(500).json({ error: 'Erreur serveur' }) }
})


module.exports = router;
